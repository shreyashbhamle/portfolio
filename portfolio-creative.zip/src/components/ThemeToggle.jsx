import React from 'react'
export default function ThemeToggle() {
  const [dark, setDark] = React.useState(() => localStorage.getItem('theme') === 'dark')
  React.useEffect(() => {
    const root = document.documentElement
    if (dark) { root.classList.add('dark'); localStorage.setItem('theme','dark') }
    else { root.classList.remove('dark'); localStorage.setItem('theme','light') }
  }, [dark])
  return (
    <button onClick={() => setDark(v => !v)} className="px-3 py-1.5 rounded-xl border border-gray-300 dark:border-gray-700 text-sm">
      {dark ? 'Light' : 'Dark'}
    </button>
  )
}
