import React from 'react'
import ThemeToggle from './ThemeToggle'
export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 backdrop-blur bg-white/60 dark:bg-gray-900/60 border-b border-gray-200/40 dark:border-gray-800/60">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
        <a href="#top" className="font-extrabold tracking-widest text-lg">SB</a>
        <nav className="hidden md:flex gap-6 text-sm font-medium">
          <a href="#about" className="hover:text-brand">About</a>
          <a href="#skills" className="hover:text-brand">Skills</a>
          <a href="#projects" className="hover:text-brand">Projects</a>
          <a href="#certifications" className="hover:text-brand">Certifications</a>
          <a href="#contact" className="hover:text-brand">Contact</a>
        </nav>
        <div className="flex items-center gap-3">
          <ThemeToggle />
          <a href="/resume.pdf" className="px-3 py-1.5 rounded-xl border border-gray-300 dark:border-gray-700 hover:border-brand">Resume</a>
        </div>
      </div>
    </header>
  )
}
