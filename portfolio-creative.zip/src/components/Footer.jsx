import React from 'react'
import { Github, Linkedin, Mail } from 'lucide-react'
import data from '../data/user.json'
export default function Footer() {
  return (
    <footer className="py-10 text-center text-sm text-gray-500">
      <div className="flex justify-center gap-5 mb-3">
        <a href={`mailto:${data.email}`} aria-label="Email"><Mail className="w-5 h-5" /></a>
        <a href={data.github} aria-label="GitHub"><Github className="w-5 h-5" /></a>
        <a href={data.linkedin} aria-label="LinkedIn"><Linkedin className="w-5 h-5" /></a>
      </div>
      <div className="h-px bg-gradient-to-r from-transparent via-indigo-500 to-transparent mb-3"></div>
      <p>© {new Date().getFullYear()} SHREYASH · R · BHAMLE — Built with React & Tailwind</p>
    </footer>
  )
}
