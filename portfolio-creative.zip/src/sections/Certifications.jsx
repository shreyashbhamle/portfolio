import React from 'react'
import { motion } from 'framer-motion'
import data from '../data/user.json'

export default function Certifications() {
  return (
    <section id="certifications" className="py-16">
      <motion.h2 initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-3xl font-semibold mb-8">Certifications & Achievements</motion.h2>
      <div className="relative pl-6">
        <div className="absolute left-3 top-0 bottom-0 w-0.5 bg-gradient-to-b from-indigo-500 to-sky-400"></div>
        <ul className="space-y-6">
          {data.certifications.map((c, i) => (
            <li key={i} className="relative">
              <div className="absolute -left-[11px] w-5 h-5 rounded-full bg-white dark:bg-gray-900 border-2 border-indigo-500 shadow-glow"></div>
              <div className="glass card p-5">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">{c.title}</h3>
                  <span className="text-xs text-gray-500">{c.date}</span>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
