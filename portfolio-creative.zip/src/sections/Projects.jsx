import React from 'react'
import { motion } from 'framer-motion'
import projects from '../data/projects.json'

export default function Projects() {
  return (
    <section id="projects" className="py-16">
      <motion.h2 initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-3xl font-semibold mb-6 text-center">Projects</motion.h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map((p, idx) => (
          <motion.article
            key={p.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: idx * 0.05 }}
            className="glass card overflow-hidden card-hover"
          >
            <div className="h-40 bg-gradient-to-br from-indigo-200/50 to-sky-200/50 dark:from-indigo-900/30 dark:to-sky-900/30"></div>
            <div className="p-5">
              <h3 className="text-lg font-bold">{p.title}</h3>
              <p className="text-sm text-gray-700 dark:text-gray-300 mt-1">{p.desc}</p>
              <div className="mt-3 flex flex-wrap gap-2">{p.tags.map(t => <span key={t} className="px-2 py-0.5 rounded-lg bg-gray-100 dark:bg-gray-800 text-xs">{t}</span>)}</div>
              <div className="mt-4 flex gap-3">
                <a className="btn-outline" href={p.github}>GitHub</a>
                <a className="btn-grad" href={p.demo}>Live</a>
              </div>
            </div>
          </motion.article>
        ))}
      </div>
    </section>
  )
}
