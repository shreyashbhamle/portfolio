import React from 'react'
import { motion } from 'framer-motion'
import Particles from 'react-tsparticles'
import data from '../data/user.json'

function useTypedCycle(words, speed=120, pause=1000) {
  const [text, setText] = React.useState('')
  const [i, setI] = React.useState(0)
  const [dir, setDir] = React.useState(1)
  const [w, setW] = React.useState(0)

  React.useEffect(() => {
    const word = words[w % words.length]
    if (dir === 1) {
      if (i <= word.length) {
        const t = setTimeout(() => setI(i+1), speed)
        setText(word.slice(0, i))
        return () => clearTimeout(t)
      } else {
        const t = setTimeout(() => setDir(-1), pause)
        return () => clearTimeout(t)
      }
    } else {
      if (i >= 0) {
        const t = setTimeout(() => setI(i-1), speed*0.6)
        setText(word.slice(0, i))
        return () => clearTimeout(t)
      } else {
        setDir(1); setW(w+1)
      }
    }
  }, [i, dir, w, words, speed, pause])

  return text
}

export default function Hero() {
  const typed = useTypedCycle(data.roleCycle, 80, 1100)

  return (
    <section id="top" className="relative py-24 sm:py-32">
      <Particles
        id="tsparticles"
        options={{
          background: { color: { value: 'transparent' } },
          fpsLimit: 60,
          interactivity: {
            events: { onHover: { enable: true, mode: 'repulse' }, resize: true },
            modes: { repulse: { distance: 100, duration: 0.4 } }
          },
          particles: {
            color: { value: '#8b5cf6' },
            links: { enable: true, color: '#60a5fa', distance: 120, opacity: 0.3 },
            move: { enable: true, speed: 1.2 },
            number: { value: 45, density: { enable: true, area: 800 } },
            opacity: { value: 0.5 },
            shape: { type: 'circle' },
            size: { value: { min: 1, max: 3 } }
          },
          detectRetina: true
        }}
        className="absolute inset-0 -z-10"
      />
      <div className="grid lg:grid-cols-2 gap-10 items-center">
        <div>
          <motion.h1
            initial={{ opacity: 0, y: -10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-5xl sm:text-6xl font-extrabold tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-600 drop-shadow"
          >
            {data.name}
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="mt-4 text-xl text-gray-700 dark:text-gray-300"
          >
            {typed || '\u00A0'}
          </motion.p>
          <div className="mt-6 flex gap-3">
            <a href="#projects" className="btn-grad">View Projects</a>
            <a href={data.resume} className="btn-outline">Download Resume</a>
          </div>
        </div>
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.15 }}
          className="relative h-64 sm:h-80 lg:h-96 glass card"
        >
          <div className="absolute inset-6 rounded-3xl border border-white/40 dark:border-white/10 animate-float"></div>
        </motion.div>
      </div>
    </section>
  )
}
