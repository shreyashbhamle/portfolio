import React from 'react'
import { motion } from 'framer-motion'
import data from '../data/user.json'

export default function Contact() {
  return (
    <section id="contact" className="py-20">
      <motion.h2 initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-3xl font-semibold mb-6 text-center">Get in Touch</motion.h2>
      <div className="max-w-2xl mx-auto glass card p-6">
        <form className="grid gap-4">
          <input name="name" placeholder="Your Name" className="px-3 py-2 rounded-xl bg-gray-100 dark:bg-gray-800 outline-none" />
          <input name="email" type="email" placeholder="Email" className="px-3 py-2 rounded-xl bg-gray-100 dark:bg-gray-800 outline-none" />
          <textarea name="message" rows="5" placeholder="Message" className="px-3 py-2 rounded-xl bg-gray-100 dark:bg-gray-800 outline-none"></textarea>
          <button type="button" className="btn-grad">Send Message</button>
        </form>
        <p className="text-center text-sm text-gray-500 mt-4">
          Or email me directly at <a className="underline" href={`mailto:${data.email}`}>{data.email}</a>
        </p>
      </div>
    </section>
  )
}
