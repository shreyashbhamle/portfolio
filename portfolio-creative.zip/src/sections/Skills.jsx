import React from 'react'
import { motion } from 'framer-motion'
import data from '../data/user.json'

function Bar({ label, value }) {
  return (
    <div>
      <div className="flex justify-between text-sm mb-1"><span>{label}</span><span>{value}%</span></div>
      <div className="h-2 rounded-full bg-gray-200 dark:bg-gray-800 overflow-hidden">
        <div className="h-full bg-gradient-to-r from-indigo-500 to-sky-400" style={{ width: value + '%' }}></div>
      </div>
    </div>
  )
}

function Radial({ label, value }) {
  const radius = 32, circumference = 2 * Math.PI * radius
  const offset = circumference - (value / 100) * circumference
  return (
    <div className="flex flex-col items-center">
      <svg width="90" height="90" className="rotate-[-90deg]">
        <circle cx="45" cy="45" r={radius} fill="none" stroke="currentColor" className="text-gray-200 dark:text-gray-800" strokeWidth="10" />
        <circle cx="45" cy="45" r={radius} fill="none" stroke="url(#grad)" strokeWidth="10" strokeDasharray={circumference} strokeDashoffset={offset} />
        <defs>
          <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#6366f1" /><stop offset="100%" stopColor="#22d3ee" />
          </linearGradient>
        </defs>
      </svg>
      <div className="-mt-16 text-xl font-bold">{value}%</div>
      <div className="mt-6 text-sm">{label}</div>
    </div>
  )
}

export default function Skills() {
  const groups = data.skills
  return (
    <section id="skills" className="py-16">
      <motion.h2 initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-3xl font-semibold mb-8">Skills</motion.h2>
      <div className="grid lg:grid-cols-2 gap-8">
        <div className="glass card p-6">
          <h3 className="font-bold mb-4">Core</h3>
          <div className="space-y-3">
            {Object.entries(groups.Languages).map(([k,v]) => <Bar key={k} label={k} value={v} />)}
            {Object.entries(groups.Frameworks).map(([k,v]) => <Bar key={k} label={k} value={v} />)}
          </div>
        </div>
        <div className="glass card p-6 grid grid-cols-2 sm:grid-cols-3 gap-6 place-items-center">
          {Object.entries(groups.ML).map(([k,v]) => <Radial key={k} label={k} value={v} />)}
          {Object.entries(groups.Tools).slice(0,3).map(([k,v]) => <Radial key={k} label={k} value={v} />)}
        </div>
      </div>
    </section>
  )
}
