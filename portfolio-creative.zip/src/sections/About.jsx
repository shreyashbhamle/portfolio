import React from 'react'
import { motion } from 'framer-motion'
import data from '../data/user.json'

export default function About() {
  const cards = [
    { title: 'Who I Am', text: data.summary },
    { title: 'What I Do', text: 'Front-end dev (React) · ML projects · Cloud basics' },
    { title: 'What I Love', text: 'Clean UI, performance, and building useful tools' }
  ]
  return (
    <section id="about" className="py-16">
      <motion.h2 initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-3xl font-semibold mb-6">About</motion.h2>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {cards.map(c => (
          <motion.div key={c.title} initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="glass card p-6 card-hover">
            <h3 className="font-bold mb-2">{c.title}</h3>
            <p className="text-gray-700 dark:text-gray-300">{c.text}</p>
          </motion.div>
        ))}
      </div>
    </section>
  )
}
